package transport.core;

public enum TypeFonction {
    AGENT,
    CONDUCTEUR

}
