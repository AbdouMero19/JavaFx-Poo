package transport.core;
public enum Typecarte {
  JUNIOR,
  SENIOR,
  SOLIDARITÉ,
  PARTENAIRE
}
